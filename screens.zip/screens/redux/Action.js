import {TOGGLE_THEME} from "./Constant";

export const changeTheme = () => {
    return {
        type : TOGGLE_THEME
    }
}